@echo off
setlocal
title Find My Portfolio - Sumit
set "PORTFOLIO_FINDER_FILE=%~f0"
where powershell.exe >nul 2>nul
if errorlevel 1 goto no_powershell
powershell.exe -NoLogo -NoProfile -Command "try { $raw=[System.IO.File]::ReadAllText($env:PORTFOLIO_FINDER_FILE); $tag='#'+'__PORTFOLIO_POWERSHELL__'; $pos=$raw.IndexOf($tag,[StringComparison]::Ordinal); if($pos -lt 0){throw 'Search script is incomplete. Download it again.'}; & ([ScriptBlock]::Create($raw.Substring($pos+$tag.Length))) } catch { Write-Host ('Search stopped: '+$_.Exception.Message); exit 1 }"
echo.
echo You can close this window after reading the result.
pause
exit /b
:no_powershell
echo Windows PowerShell is not available on this computer.
echo Send a photo of this message so the search can be adapted.
pause
exit /b 1
#__PORTFOLIO_POWERSHELL__

# Windows PowerShell 5.1 compatible. Local search only; no website code is run.
$ErrorActionPreference = 'Stop'
$script:matches = @{}
$script:rootCache = @{}
$script:stats = @{ Folders=0; Files=0; TextFiles=0; Zips=0; Skipped=0; Limits=0; Offline=0; Nested=0 }
$script:watch = [Diagnostics.Stopwatch]::StartNew()
$script:lastProgress = -2
$script:notes = [Collections.Generic.List[string]]::new()
$script:outputDirectory = $null
$script:lastReport = 0
$script:roots = @()
$script:zipSupported = $false
$script:completed = $false
$script:previousMonth = (Get-Date -Day 1).Date.AddMonths(-1)
$script:thisMonth = (Get-Date -Day 1).Date
$script:baseline = @('1202028802','1201158426','291qhew0lz','yamjrjtwzr','1187557707','1209002875','1187558561','3sdb6g58ql','8y2djlrpef')
$script:skipNames = @('Windows','Windows.old','Program Files','Program Files (x86)','ProgramData',
    '$Recycle.Bin','System Volume Information','Recovery','Config.Msi','node_modules','.git',
    '.svn','.hg','.pnpm-store','.npm','.yarn','__pycache__','.venv','venv',
    'AppData','Cache','Caches','GPUCache','Code Cache','Service Worker')
$script:textExtensions = @('.html','.htm','.js','.jsx','.ts','.tsx','.vue','.svelte','.astro',
    '.json','.md','.mdx','.txt','.php','.mjs','.cjs')
$script:rules = @(
    @{ Name='Name: Sumit Solanki'; Pattern='(?i)sumit[\s_./-]*solanki'; Weight=60; Identity=$true },
    @{ Name='Email: sumitxpnp@gmail.com'; Pattern='(?i)sumitxpnp\s*@\s*gmail\.com'; Weight=70; Identity=$true },
    @{ Name='Brand: suumitx / sumitx / swmitx'; Pattern='(?i)(?<![a-z])(?:suumitx|sumitx|swmitx)(?![a-z])'; Weight=50; Identity=$true },
    @{ Name='Known video from uploaded ZIP'; Pattern='(?i)(?:1202028802|1201158426|291qhew0lz|yamjrjtwzr|1187557707|1209002875|1187558561|3sdb6g58ql|8y2djlrpef)'; Weight=50; Identity=$true },
    @{ Name='Video editor'; Pattern='(?i)video[\s_/-]*edit(?:or|ing)'; Weight=6; Identity=$false },
    @{ Name='Motion designer'; Pattern='(?i)motion[\s_/-]*(?:design(?:er)?|graphics)'; Weight=6; Identity=$false },
    @{ Name='Cinematic'; Pattern='(?i)cinematic'; Weight=3; Identity=$false },
    @{ Name='Portfolio / showreel'; Pattern='(?i)portfolio|showreel|selected\s+work'; Weight=4; Identity=$false },
    @{ Name='Vimeo'; Pattern='(?i)vimeo\.com'; Weight=3; Identity=$false },
    @{ Name='Wistia'; Pattern='(?i)wistia\.(?:com|net)'; Weight=3; Identity=$false },
    @{ Name='YouTube'; Pattern='(?i)youtube\.com|youtu\.be'; Weight=2; Identity=$false }
)

function Add-Note([string]$message) {
    $script:stats.Skipped++
    if ($script:notes.Count -lt 400) { [void]$script:notes.Add($message) }
}

function Get-ProjectRoot([string]$directory) {
    if ($script:rootCache.ContainsKey($directory)) { return $script:rootCache[$directory] }
    $current = $directory
    $fallback = $directory
    $answer = $null
    for ($depth=0; $depth -lt 14 -and $current; $depth++) {
        try {
            if ([IO.File]::Exists([IO.Path]::Combine($current,'package.json'))) { $answer=$current; break }
            if ([IO.File]::Exists([IO.Path]::Combine($current,'index.html')) -or
                [IO.File]::Exists([IO.Path]::Combine($current,'index.htm'))) { $answer=$current; break }
            $name = [IO.Path]::GetFileName($current.TrimEnd([char]'\'))
            if ($name -in @('src','dist','public','build','out','.next','.output')) {
                $parent = [IO.Directory]::GetParent($current)
                if ($parent) { $fallback=$parent.FullName }
            }
            $parent = [IO.Directory]::GetParent($current)
            if (-not $parent) { break }
            $current = $parent.FullName
        } catch { break }
    }
    if (-not $answer) { $answer=$fallback }
    $script:rootCache[$directory]=$answer
    return $answer
}

function Get-Candidate([string]$key,[string]$kind,[datetime]$modified) {
    if (-not $script:matches.ContainsKey($key)) {
        $set = [StringComparer]::OrdinalIgnoreCase
        $script:matches[$key] = @{
            Path=$key; Kind=$kind; Modified=$modified; Score=0; Identity=$false; PathHint=$false;
            Hits=[Collections.Generic.HashSet[string]]::new($set);
            Videos=[Collections.Generic.HashSet[string]]::new($set);
            VideoIds=[Collections.Generic.HashSet[string]]::new($set);
            Samples=[Collections.Generic.HashSet[string]]::new($set);
            Titles=[Collections.Generic.HashSet[string]]::new($set);
            PreviousMonth=$false
        }
    }
    $item=$script:matches[$key]
    if ($modified -gt $item.Modified) { $item.Modified=$modified }
    if ($modified -ge $script:previousMonth -and $modified -lt $script:thisMonth) { $item.PreviousMonth=$true }
    return $item
}

function Add-PathCandidate([string]$key,[string]$kind,[datetime]$modified) {
    if ($key -match '(?i)portfolio|sumit|solanki|suumitx|swmitx') {
        $item=Get-Candidate $key $kind $modified
        $item.PathHint=$true
        if ($item.Hits.Add('Folder/archive name clue')) { $item.Score+=8 }
    }
}

function Inspect-Text([string]$text,[string]$root,[string]$kind,[datetime]$modified,[string]$evidence) {
    if ([string]::IsNullOrEmpty($text)) { return }
    $found=[Collections.Generic.List[object]]::new()
    foreach ($rule in $script:rules) {
        if ([regex]::IsMatch($text,$rule.Pattern)) { [void]$found.Add($rule) }
    }
    $pathHint=$root -match '(?i)portfolio|sumit|solanki|suumitx|swmitx'
    if ($found.Count -eq 0 -and -not $pathHint) { return }
    $item=Get-Candidate $root $kind $modified
    if ($pathHint) {
        $item.PathHint=$true
        if ($item.Hits.Add('Folder/archive name clue')) { $item.Score+=8 }
    }
    foreach ($rule in $found) {
        if ($item.Hits.Add($rule.Name)) { $item.Score+=$rule.Weight }
        if ($rule.Identity) { $item.Identity=$true }
    }
    if ($item.Samples.Count -lt 10) { [void]$item.Samples.Add($evidence) }
    $title=[regex]::Match($text,'(?is)<title\b[^>]*>([^<]{1,250})</title>')
    if ($title.Success -and $item.Titles.Count -lt 5) {
        [void]$item.Titles.Add([Net.WebUtility]::HtmlDecode($title.Groups[1].Value.Trim()))
    }
    $normalized=$text.Replace('\/','/')
    $urlPattern='(?i)https?://[^\s<>"''`\\]{1,1000}'
    foreach ($match in [regex]::Matches($normalized,$urlPattern)) {
        $url=$match.Value.TrimEnd([char[]]'),;]}')
        if ($url -match '(?i)(?:vimeo\.com|wistia\.(?:com|net)|youtube\.com|youtu\.be|cloudinary\.com/.*/video/|\.(?:mp4|webm|mov|m4v)(?:[?#]|$))') {
            if ($item.Videos.Count -lt 300) { [void]$item.Videos.Add($url) }
        }
    }
    $idPatterns=@(
        '(?i)vimeo\.com/(?:video/)?(\d{6,12})',
        '(?i)wistia\.(?:com|net)/(?:embed/)?medias/([a-z0-9]{8,16})',
        '(?i)youtu\.be/([a-z0-9_-]{11})',
        '(?i)youtube\.com/(?:watch\?[^\s"''`<>]*?v=|embed/|shorts/)([a-z0-9_-]{11})',
        '(?i)["''`]?videoId["''`]?\s*[:=]\s*["''`]([a-z0-9_-]{6,24})'
    )
    foreach ($pattern in $idPatterns) {
        foreach ($match in [regex]::Matches($normalized,$pattern)) {
            if ($item.VideoIds.Count -lt 300) { [void]$item.VideoIds.Add($match.Groups[1].Value) }
        }
    }
}

function Read-SourceFile([IO.FileInfo]$file) {
    try {
        if ($file.Length -gt 16MB) { $script:stats.Limits++; return }
        # Avoid automatically downloading cloud-only placeholders.
        if (([int64]$file.Attributes -band 0x401000) -ne 0) { $script:stats.Offline++; return }
        $root=Get-ProjectRoot $file.DirectoryName
        $stream=$null; $reader=$null
        try {
            $stream=[IO.File]::Open($file.FullName,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::ReadWrite)
            $reader=[IO.StreamReader]::new($stream,[Text.Encoding]::UTF8,$true)
            $text=$reader.ReadToEnd()
        } finally {
            if ($reader) { $reader.Dispose() } elseif ($stream) { $stream.Dispose() }
        }
        $script:stats.TextFiles++
        Inspect-Text $text $root 'Folder' $file.LastWriteTime $file.FullName
    } catch { Add-Note ('File skipped: '+$file.FullName+' | '+$_.Exception.Message) }
}

function Read-Zip([IO.FileInfo]$file) {
    $script:stats.Zips++
    Add-PathCandidate $file.FullName 'ZIP' $file.LastWriteTime
    if (-not $script:zipSupported) { Add-Note ('ZIP support unavailable: '+$file.FullName); return }
    if (([int64]$file.Attributes -band 0x401000) -ne 0) { $script:stats.Offline++; return }
    $archive=$null
    $budget=0L
    try {
        $archive=[IO.Compression.ZipFile]::OpenRead($file.FullName)
        foreach ($entry in $archive.Entries) {
            if ([string]::IsNullOrEmpty($entry.Name)) { continue }
            $entryPath=$entry.FullName.Replace('\','/')
            if ($entryPath -match '(?i)(^|/)(node_modules|\.git|\.svn|\.hg|\.pnpm-store|\.npm|\.yarn|__pycache__|\.venv|venv|AppData|Cache|Caches)(/|$)') { continue }
            $extension=[IO.Path]::GetExtension($entry.Name).ToLowerInvariant()
            if ($extension -eq '.zip') { $script:stats.Nested++; continue }
            if ($extension -notin $script:textExtensions) { continue }
            if ($entry.Name -match '(?i)^(package-lock\.json|yarn\.lock|pnpm-lock\.yaml)$' -or $entry.Name -match '(?i)\.d\.ts$') { continue }
            if ($entry.Length -gt 16MB) { $script:stats.Limits++; continue }
            if ($budget+$entry.Length -gt 128MB) {
                $script:stats.Limits++
                Add-Note ('ZIP text budget reached (128 MB): '+$file.FullName)
                break
            }
            $budget+=$entry.Length
            $reader=$null; $stream=$null
            try {
                $stream=$entry.Open()
                $reader=[IO.StreamReader]::new($stream,[Text.Encoding]::UTF8,$true)
                $text=$reader.ReadToEnd()
                $script:stats.TextFiles++
                # Entry timestamps describe source files; ZIP file date is also retained as the latest hint.
                $entryTime=$entry.LastWriteTime.LocalDateTime
                Inspect-Text $text $file.FullName 'ZIP' $entryTime ($file.FullName+' :: '+$entry.FullName)
                if ($script:matches.ContainsKey($file.FullName)) {
                    $candidate=$script:matches[$file.FullName]
                    if ($file.LastWriteTime -gt $candidate.Modified) { $candidate.Modified=$file.LastWriteTime }
                }
            } catch { Add-Note ('ZIP entry skipped: '+$file.FullName+' :: '+$entry.FullName) }
            finally { if ($reader) { $reader.Dispose() } elseif ($stream) { $stream.Dispose() } }
        }
    } catch { Add-Note ('Archive skipped: '+$file.FullName+' | '+$_.Exception.Message) }
    finally { if ($archive) { $archive.Dispose() } }
}

function Get-ReportRows {
    foreach ($item in $script:matches.Values) {
        # Require personal evidence, a useful filename clue, or several independent portfolio clues.
        if (-not $item.Identity -and -not $item.PathHint -and $item.Hits.Count -lt 3) { continue }
        $otherIds=@($item.VideoIds | Where-Object { $_ -notin $script:baseline })
        $confidence='Possible portfolio'
        if ($item.Identity) { $confidence='Personal match' }
        elseif ($item.PathHint -and $item.Hits.Count -le 1) { $confidence='Name clue only' }
        [pscustomobject]@{
            Match=$confidence; Score=$item.Score; Modified=$item.Modified.ToString('yyyy-MM-dd HH:mm:ss');
            HasPreviousMonthFile=$item.PreviousMonth; Kind=$item.Kind; VideoIdCount=$item.VideoIds.Count;
            IdsNotInUploadedZIP=$otherIds.Count; Path=$item.Path;
            Titles=([string]::Join(' | ',[string[]]@($item.Titles)));
            Clues=([string]::Join('; ',[string[]]@($item.Hits)));
            VideoIDs=([string]::Join('; ',[string[]]@($item.VideoIds)));
            OtherVideoIDs=([string]::Join('; ',[string[]]$otherIds));
            Evidence=([string]::Join(' | ',[string[]]@($item.Samples)))
        }
    }
}

function Html([object]$value) { return [Net.WebUtility]::HtmlEncode([string]$value) }

function Save-Reports {
    if (-not $script:outputDirectory) { return }
    $rows=@(Get-ReportRows)
    $ranked=@($rows | Sort-Object @{Expression='Score';Descending=$true},@{Expression='Modified';Descending=$true})
    $latest=@($rows | Sort-Object Modified -Descending)
    $oldest=@($rows | Sort-Object Modified)
    $different=@($rows | Where-Object { $_.IdsNotInUploadedZIP -gt 0 } | Sort-Object @{Expression='Score';Descending=$true},@{Expression='Modified';Descending=$true})
    $utf8=[Text.UTF8Encoding]::new($true)
    foreach ($pair in @(@('all-matches.csv',$ranked),@('newest-first.csv',$latest),@('oldest-first.csv',$oldest))) {
        $destination=Join-Path $script:outputDirectory $pair[0]
        if (@($pair[1]).Count -gt 0) { $pair[1] | Export-Csv -LiteralPath $destination -NoTypeInformation -Encoding UTF8 }
        else { [IO.File]::WriteAllText($destination,'No matching websites found yet.',$utf8) }
    }
    $lines=[Collections.Generic.List[string]]::new()
    [void]$lines.Add('FIND MY PORTFOLIO - RESULTS')
    [void]$lines.Add(('Run: '+(Get-Date).ToString('yyyy-MM-dd HH:mm:ss')))
    [void]$lines.Add(('Status: '+$(if($script:completed){'Finished'}else{'Partial - scan in progress or interrupted'})))
    [void]$lines.Add(('Search roots: '+[string]::Join('; ',[string[]]$script:roots)))
    [void]$lines.Add(('Candidates: '+$rows.Count+' | Folders: '+$script:stats.Folders+' | Source files: '+$script:stats.TextFiles+' | ZIPs: '+$script:stats.Zips))
    [void]$lines.Add('')
    [void]$lines.Add('STRONGEST MATCHES (first 50)')
    foreach ($row in @($ranked | Select-Object -First 50)) {
        [void]$lines.Add('')
        [void]$lines.Add(('['+$row.Match+'] Score '+$row.Score+' | '+$row.Modified+' | '+$row.Kind))
        [void]$lines.Add(('PATH: '+$row.Path))
        [void]$lines.Add(('TITLE: '+$row.Titles))
        [void]$lines.Add(('CLUES: '+$row.Clues))
        [void]$lines.Add(('VIDEO IDs: '+$row.VideoIdCount+' | IDs not in supplied ZIP: '+$row.IdsNotInUploadedZIP))
    }
    [void]$lines.Add('')
    [void]$lines.Add('VERSIONS WITH VIDEO IDs DIFFERENT FROM THE SUPPLIED ZIP (first 30)')
    foreach ($row in @($different | Select-Object -First 30)) {
        [void]$lines.Add(($row.Modified+' | '+$row.Path+' | Other IDs: '+$row.OtherVideoIDs))
    }
    [void]$lines.Add('')
    [void]$lines.Add('Dates are clues, not proof of the newest website: copying/extracting can change dates.')
    [void]$lines.Add('Different video IDs do not prove a newer version. Compare the actual videos.')
    [void]$lines.Add('ZIP candidates can contain more than one website. Evidence lists show matching files.')
    [void]$lines.Add('Send TOP-MATCHES.txt first. Keep all-matches.csv if there are many candidates.')
    [IO.File]::WriteAllLines((Join-Path $script:outputDirectory 'TOP-MATCHES.txt'),[string[]]$lines,$utf8)
    $videoRows=@(foreach ($row in $ranked) {
        foreach ($url in $script:matches[$row.Path].Videos) { [pscustomobject]@{ Path=$row.Path; VideoURL=$url } }
    })
    if ($videoRows.Count -gt 0) {
        $videoRows | Export-Csv -LiteralPath (Join-Path $script:outputDirectory 'video-links.csv') -NoTypeInformation -Encoding UTF8
    } else { [IO.File]::WriteAllText((Join-Path $script:outputDirectory 'video-links.csv'),'No video URLs found yet.',$utf8) }
    $html=[Text.StringBuilder]::new()
    [void]$html.Append('<!doctype html><html><head><meta charset="utf-8"><title>Portfolio search results</title><style>body{font:16px Segoe UI,Arial,sans-serif;max-width:1200px;margin:30px auto;padding:20px;background:#f7f4ed;color:#211d18}h1{font-size:30px}article{background:white;padding:20px;margin:18px 0;border:1px solid #ddd}code{display:block;white-space:pre-wrap;overflow-wrap:anywhere;background:#f4f1e9;padding:12px}small{color:#62584c}a{color:#9c201b}p{overflow-wrap:anywhere}</style></head><body><h1>Portfolio search results</h1>')
    [void]$html.Append(('<p>'+$(if($script:completed){'Finished'}else{'Partial results'})+' &middot; '+$rows.Count+' candidates. Ranked by personal clues, then date.</p><p>Use newest-first.csv / oldest-first.csv for every version. Dates and different video IDs are clues, not proof of a newer version.</p>'))
    foreach ($row in $ranked) {
        [void]$html.Append(('<article><h2>'+ (Html $row.Titles)+'</h2><small>'+(Html $row.Match)+' | Score '+$row.Score+' | '+(Html $row.Modified)+' | '+(Html $row.Kind)+'</small><code>'+(Html $row.Path)+'</code><p>'+(Html $row.Clues)+'</p><p>Video IDs: '+$row.VideoIdCount+' | IDs not in uploaded ZIP: '+$row.IdsNotInUploadedZIP+'</p><details><summary>Matching files and video links</summary><p>'+(Html $row.Evidence)+'</p>'))
        foreach ($url in $script:matches[$row.Path].Videos) { [void]$html.Append(('<p><a href="'+(Html $url)+'" rel="noreferrer">'+(Html $url)+'</a></p>')) }
        [void]$html.Append('</details></article>')
    }
    [void]$html.Append('</body></html>')
    [IO.File]::WriteAllText((Join-Path $script:outputDirectory 'search-report.html'),$html.ToString(),$utf8)
    $summary=@(
        'SEARCH COVERAGE',
        ('Complete: '+$script:completed),
        ('Elapsed minutes: '+[math]::Round($script:watch.Elapsed.TotalMinutes,1)),
        ('Skipped/unreadable items: '+$script:stats.Skipped),
        ('Cloud-only placeholders skipped: '+$script:stats.Offline),
        ('File/archive size limits reached: '+$script:stats.Limits),
        ('Nested ZIP entries not opened: '+$script:stats.Nested),
        'Source text limit: 16 MB per file/ZIP entry; 128 MB source text per ZIP.',
        'Skipped folder names: Windows, Program Files, ProgramData, AppData, caches, node_modules, Git internals, Python environments, recycle/system folders.',
        'Junctions and symbolic links are skipped. External connected ready drives are included in full scan.',
        'RAR/7Z archives are name-matched only; their content is not scanned. ZIP inside ZIP is not scanned.',
        'Only local copies are searched. Online accounts, deleted files and browser history are not searched.',
        'Reports are local. No source files were changed, extracted, executed, deleted or uploaded.',
        'Details (first 400):'
    )+@($script:notes)
    [IO.File]::WriteAllLines((Join-Path $script:outputDirectory 'scan-notes.txt'),[string[]]$summary,$utf8)
    return $rows.Count
}

function Show-Progress([string]$path) {
    $seconds=[int]$script:watch.Elapsed.TotalSeconds
    if ($seconds - $script:lastProgress -ge 2) {
        $script:lastProgress=$seconds
        Write-Progress -Activity 'Finding your portfolio - local files and ZIP archives' -Status ($script:stats.Folders.ToString()+' folders | '+$script:stats.TextFiles+' source files | '+$script:stats.Zips+' ZIPs | '+[math]::Round($seconds/60,1)+' min') -CurrentOperation $path
        if ($seconds-$script:lastReport -ge 60) {
            $script:lastReport=$seconds
            try { [void](Save-Reports) } catch { Add-Note ('Partial report could not be refreshed: '+$_.Exception.Message) }
        }
    }
}

try {
    try { Add-Type -AssemblyName System.IO.Compression.FileSystem; $script:zipSupported=$true }
    catch { Add-Note 'ZIP reader is unavailable; folder search will still run.' }
    Write-Host ''
    Write-Host 'FIND MY PORTFOLIO - SUMIT' -ForegroundColor Cyan
    Write-Host 'Searches names, email, portfolio text and video links, including ZIP contents.'
    Write-Host 'No admin rights or installations needed. Source files stay unchanged.'
    Write-Host ''
    Write-Host '1 = All ready local/external drives (thorough; recommended)'
    Write-Host '2 = One folder or drive that you choose'
    Write-Host '3 = Your user folder only (faster)'
    $choice=Read-Host 'Choose 1 / 2 / 3, or press Enter for 1'
    if ($choice -eq '2') {
        $chosen=(Read-Host 'Paste folder/drive path, e.g. D:\ or D:\Projects').Trim().Trim([char]'"')
        if (-not [IO.Directory]::Exists($chosen)) { throw 'That folder was not found. Run again and paste an existing folder path.' }
        $script:roots=@([IO.Path]::GetFullPath($chosen))
    } elseif ($choice -eq '3') {
        $script:roots=@([Environment]::GetFolderPath('UserProfile'))
    } else {
        $script:roots=@(foreach ($drive in [IO.DriveInfo]::GetDrives()) {
            try { if ($drive.IsReady -and $drive.DriveType -in @([IO.DriveType]::Fixed,[IO.DriveType]::Removable)) { $drive.RootDirectory.FullName } } catch { }
        })
    }
    if ($script:roots.Count -eq 0) { throw 'No ready local drives were found. Run again and choose option 2.' }
    $stamp=Get-Date -Format 'yyyyMMdd-HHmmss-fff'
    foreach ($base in @([Environment]::GetFolderPath('Desktop'),[Environment]::GetFolderPath('UserProfile'),[IO.Path]::GetTempPath())) {
        if ([string]::IsNullOrWhiteSpace($base)) { continue }
        try {
            $destination=Join-Path $base ('Portfolio-Search-'+$stamp)
            [void][IO.Directory]::CreateDirectory($destination)
            $test=Join-Path $destination 'scan-notes.txt'
            [IO.File]::WriteAllText($test,'Search started. Reports will update during the scan.')
            $script:outputDirectory=$destination
            break
        } catch { }
    }
    if (-not $script:outputDirectory) { throw 'Could not create a report folder on Desktop, your user folder or TEMP.' }
    Write-Host ''
    Write-Host ('Reports: '+$script:outputDirectory) -ForegroundColor Yellow
    Write-Host 'Keep this window open. Progress and partial reports refresh while scanning.'
    [void](Save-Reports)
    $stack=[Collections.Generic.Stack[string]]::new()
    foreach ($root in $script:roots) { $stack.Push($root) }
    $visited=[Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    while ($stack.Count -gt 0) {
        $folder=$stack.Pop()
        if (-not $visited.Add($folder)) { continue }
        if ($folder.StartsWith($script:outputDirectory,[StringComparison]::OrdinalIgnoreCase)) { continue }
        Show-Progress $folder
        try {
            $directory=[IO.DirectoryInfo]::new($folder)
            $children=$directory.GetFileSystemInfos()
            $script:stats.Folders++
        } catch { Add-Note ('Folder skipped: '+$folder); continue }
        foreach ($child in $children) {
            try {
                if (($child.Attributes -band [IO.FileAttributes]::Directory) -ne 0) {
                    if ($child.Name -in $script:skipNames) { continue }
                    if (($child.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
                        # LinkType is populated for junctions/symlinks, unlike ordinary cloud folders.
                        $link=Get-Item -LiteralPath $child.FullName -Force -ErrorAction Stop
                        if ($link.LinkType -in @('Junction','SymbolicLink')) { continue }
                    }
                    $stack.Push($child.FullName)
                    continue
                }
                $script:stats.Files++
                $extension=$child.Extension.ToLowerInvariant()
                if ($extension -eq '.zip') { Show-Progress $child.FullName; Read-Zip $child; continue }
                if ($extension -in @('.rar','.7z')) { Add-PathCandidate $child.FullName 'Archive (name only)' $child.LastWriteTime; continue }
                if ($extension -notin $script:textExtensions) { continue }
                if ($child.Name -match '(?i)^(package-lock\.json|yarn\.lock|pnpm-lock\.yaml)$' -or $child.Name -match '(?i)\.d\.ts$') { continue }
                Read-SourceFile $child
            } catch { Add-Note ('Item skipped: '+$child.FullName) }
        }
    }
    $script:completed=$true
} catch {
    Write-Host ''
    Write-Host ('Search stopped: '+$_.Exception.Message) -ForegroundColor Yellow
    if ($script:outputDirectory) { Add-Note ('Stopped early: '+$_.Exception.Message) }
} finally {
    Write-Progress -Activity 'Finding your portfolio - local files and ZIP archives' -Completed
    if ($script:outputDirectory) {
        try {
            $total=Save-Reports
            Write-Host ''
            Write-Host ('REPORT READY: '+$total+' candidate(s).') -ForegroundColor Green
            Write-Host ('Folder: '+$script:outputDirectory)
            Write-Host 'Send TOP-MATCHES.txt first. It includes paths, dates and video ID comparisons.'
            Write-Host 'newest-first.csv and oldest-first.csv list all candidate versions by date.'
            if (-not $script:completed) { Write-Host 'The report contains partial results because the scan did not finish.' -ForegroundColor Yellow }
            try { Start-Process -FilePath notepad.exe -ArgumentList ('"'+(Join-Path $script:outputDirectory 'TOP-MATCHES.txt')+'"') } catch { }
        } catch { Write-Host ('Could not finish reports: '+$_.Exception.Message) -ForegroundColor Yellow }
    }
}
